# Progetto HPC A.A. 2023/24
Alessandro Monticelli.

Either read the README.md or the Makefile inside the src directory for compilation instructions.
